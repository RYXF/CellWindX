#' @importFrom stats ave median setNames
#' @importFrom utils write.csv
NULL

utils::globalVariables(c(
  "gene",
  "target_cluster",
  "pct_expr",
  "avg_expr",
  "axis_id",
  "x",
  "y",
  "grid_level",
  "xend",
  "yend",
  "label",
  "marker_id",
  "value"
))
